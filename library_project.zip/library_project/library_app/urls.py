from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('api/books/', views.BookListCreate.as_view(), name='book-list-create'),
    path('api/books/<int:pk>/', views.BookDetail.as_view(), name='book-detail'),
]
