from django.db import models

class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=200)
    published_date = models.DateField(null=True, blank=True)
    isbn = models.CharField(max_length=20, blank=True)
    pages = models.PositiveIntegerField(null=True, blank=True)
    cover = models.URLField(blank=True)
    language = models.CharField(max_length=50, blank=True)

    def __str__(self):
        return self.title
